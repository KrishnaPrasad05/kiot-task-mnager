import React, { useState, useEffect } from 'react';
import { View, Text, FlatList, TouchableOpacity, StyleSheet, RefreshControl ,Image} from 'react-native';
import { useNavigation } from '@react-navigation/native';

const HomePageFac = () => {
    const navigation = useNavigation();

    const handleAssignTask = () => {
      // Navigate to the other page when the button is pressed
      navigation.navigate('AssignedTask'); // Replace 'OtherPage' with the name of the target screen
    };
    const handleAssignCCR = () => {
      // Navigate to the other page when the button is pressed
      navigation.navigate('AssignedCCR'); // Replace 'OtherPage' with the name of the target screen
    };
    
    const handleProfile = () => {
      // Navigate to the other page when the button is pressed
      navigation.navigate('ProfileFac'); // Replace 'OtherPage' with the name of the target screen
    };
  
    return(

<View style={{display:'flex',justifyContent:'center',alignItems:'center',marginTop:50}}>
<TouchableOpacity onPress={handleAssignTask}>
    <View style={{backgroundColor:'#D0EFCB',padding:30,width:300,display:'flex',justifyContent:'center',alignItems:'center',borderRadius:20,marginBottom:30}}>
    <Image source={require('../../assets/Images/list 1.png')} style={{width:100,height:100}} />
    <Text>Assigned Task</Text>
    </View>
    </TouchableOpacity>
<TouchableOpacity onPress={handleAssignCCR}>
    <View style={{backgroundColor:'#D0EFCB',padding:30,width:300,display:'flex',justifyContent:'center',alignItems:'center',borderRadius:20,marginBottom:30}}>
    <Image source={require('../../assets/Images/call (1).png')} style={{width:100,height:100}} />
    <Text>Assigned CCR</Text>
    </View>
    </TouchableOpacity>
    <TouchableOpacity onPress={handleProfile}>
    <View style={{backgroundColor:'#D0EFCB',padding:30,width:300,display:'flex',justifyContent:'center',alignItems:'center',borderRadius:20}}>
    <Image source={require('../../assets/Images/man 1.png')} style={{width:100,height:100}} />
    <Text>Profile</Text>
    </View>
    </TouchableOpacity>
</View>
    );
}
export default HomePageFac;