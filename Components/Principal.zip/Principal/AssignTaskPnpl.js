import React, { useContext, useState } from 'react';
import { View, Text, TextInput, Button, StyleSheet, Alert,TouchableOpacity, ScrollView,Image} from 'react-native';
import DateTimePickerModal from "react-native-modal-datetime-picker";
import { Picker } from '@react-native-picker/picker';
import { useNavigation } from '@react-navigation/native';
import AppContext from '../AppContext';
const AssignTaskPnpl = () => {

  const navigation = useNavigation();
  const [taskName, setTaskName] = useState('');
  const [assignTo, setAssignTo] = useState('');
  const [description, setDescription] = useState('');
  const [date, setDate] = useState('');
  const [time, setTime] = useState('');
  const [priority, setPriority] = useState('medium');
  const [status, setStatus] = useState('Pending');
  const { variableValue, setVariableValue } = useContext(AppContext);
  const [isDatePickerVisible, setDatePickerVisibility] = useState(false);
  const [isTimePickerVisible, setTimePickerVisibility] = useState(false);

  const showDatePicker = () => {
    setDatePickerVisibility(true);
  };

  const hideDatePicker = () => {
    setDatePickerVisibility(false);
  };

  const handleDateConfirm = (selectedDate) => {
    hideDatePicker();
    setDate(selectedDate.toISOString().split('T')[0]);
  };

  const showTimePicker = () => {
    setTimePickerVisibility(true);
  };

  const hideTimePicker = () => {
    setTimePickerVisibility(false);
  };

  const handleTimeConfirm = (selectedTime) => {
    hideTimePicker();
    setTime(selectedTime.toLocaleTimeString());
  };

  
   
  const handleSave = async () => {
    const createdAt = new Date().toLocaleString('en-US', { 
        year: 'numeric', 
        month: '2-digit', 
        day: '2-digit', 
        hour: '2-digit', 
        minute: '2-digit', 
        second: '2-digit' 
      });
    const taskData = {
      taskName,
      assignTo,
      description,
      date,
      time,
      priority,
      createdAt,
      status
    };

    if (!taskName || !assignTo || !description || !date || !time || !priority) {
        Alert.alert('Error', 'Please fill in all fields');
        return;
      }
    try {
      const response = await fetch(`http://${variableValue}/tasks`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(taskData),
      });

      if (response.ok) {
        Alert.alert('Success', 'Task added successfully');
        // Clear input fields
        setTaskName('');
        setAssignTo('');
        setDescription('');
        setDate('');
        setTime('');
        setPriority('');
      } else {
        Alert.alert('Error', 'Failed to add user');
      }

      // Task saved successfully
      console.log('Task saved successfully');
    } catch (error) {
      console.error('Error saving task:', error);
    }
  };

  const handleReset = () => {
    // Reset all form fields
    setTaskName('');
    setAssignTo('');
    setDescription('');
    setDate('');
    setTime('');
    setPriority('');
  };

  const handleProfile = () => {
    // Navigate to the other page when the button is pressed
    navigation.navigate('ProfilePnpl'); // Replace 'OtherPage' with the name of the target screen
  };
  const handleHome = () => {
    // Navigate to the other page when the button is pressed
    navigation.navigate('HomePagePnpl'); // Replace 'OtherPage' with the name of the target screen
  };
  const handleAdd = () => {
    // Navigate to the other page when the button is pressed
    navigation.navigate('AddFacultyPnpl'); // Replace 'OtherPage' with the name of the target screen
  };
  const handleView = () => {
    // Navigate to the other page when the button is pressed
    navigation.navigate('ViewFacultyPnpl'); // Replace 'OtherPage' with the name of the target screen
  };

  return (
    <ScrollView>

   
    
    <View style={styles.container}>
      

        
      <Text style={styles.label}>Task Name:</Text>
      <TextInput
        style={styles.input}
        value={taskName}
        onChangeText={text => setTaskName(text)}
        placeholder="Enter task name"
      />
      <Text style={styles.label}>Assign To:</Text>
      <TextInput
        style={styles.input}
        value={assignTo}
        onChangeText={text => setAssignTo(text)}
        placeholder="Enter assignee name"
      />
      <Text style={styles.label}>Description:</Text>
      <TextInput
        style={styles.textArea}
        value={description}
        onChangeText={text => setDescription(text)}
        placeholder="Enter description"
        multiline={true}
        numberOfLines={4}
      />
      <View style={{display:'flex',alignItems:'center',justifyContent:'space-between',flexDirection:'row'}}>
        <View>
        <Text style={styles.label}>Date:</Text>
      <TextInput
        style={{height: 40,
            borderWidth: 1,
            backgroundColor:'#D0EFCB',
            borderColor: 'black',
            borderRadius: 5,
            paddingHorizontal: 10,
            marginBottom: 20,width:170}}
        value={date}
        placeholder="Select date"
        onFocus={showDatePicker}
      />
      <DateTimePickerModal
        isVisible={isDatePickerVisible}
        mode="date"
        onConfirm={handleDateConfirm}
        onCancel={hideDatePicker}
      />
        </View>
        <View>
        <Text style={styles.label}>Time:</Text>
      <TextInput
        style={{height: 40,
            borderWidth: 1,
            backgroundColor:'#D0EFCB',
            borderColor: 'black',
            borderRadius: 5,
            paddingHorizontal: 10,
            marginBottom: 20,width:170}}
        value={time}
        placeholder="Select time"
        onFocus={showTimePicker}
      />
      <DateTimePickerModal
        isVisible={isTimePickerVisible}
        mode="time"
        onConfirm={handleTimeConfirm}
        onCancel={hideTimePicker}
      />
        </View>
     
     
      </View>
    
      <Text style={styles.label}>Priority:</Text>
      <Picker
        selectedValue={priority}
        style={styles.picker}
        onValueChange={(itemValue, itemIndex) => setPriority(itemValue)}
      >
        <Picker.Item label="High" value="high" />
        <Picker.Item label="Medium" value="medium" />
        <Picker.Item label="Low" value="low" />
      </Picker>

      <View style={{display:'flex',alignItems:'center',justifyContent:'space-around',flexDirection:'row'}}>
     <TouchableOpacity >
        <Text style={styles.button2} onPress={handleReset}>Reset</Text>
      </TouchableOpacity>
      <TouchableOpacity onPress={handleSave}>
        <Text style={styles.button1}>Assign</Text>
      </TouchableOpacity>
     </View>
    

     <View style={{display:'flex',flexDirection:'row',alignItems:'center',justifyContent:'space-between',backgroundColor:'#fafafa',width:"100%",padding:20,marginTop:50}}>

<TouchableOpacity onPress={handleHome}>
  <View >
    
  <Image source={require('../../assets/Images/home.png')} style={{width:25,height:25}} />
 
  </View>
  </TouchableOpacity>
  <TouchableOpacity onPress={handleAdd}>
  <View >
  <Image source={require('../../assets/Images/add-friend.png')} style={{width:25,height:25}} />
  
  </View>
  </TouchableOpacity>
  <TouchableOpacity onPress={handleView}>
  <View style={{backgroundColor:'transparent',padding:10,borderRadius:5,display:'flex',alignItems:'center',justifyContent:'center',width:60,height:60}}>
  <Image source={require('../../assets/Images/list.png')} style={{width:25,height:25}} />
  <Text>View</Text>
  </View>
  </TouchableOpacity>
  <TouchableOpacity onPress={handleProfile}>
  <View >
  <Image source={require('../../assets/Images/user (2).png')} style={{width:25,height:25}} />
  </View>
  </TouchableOpacity>
</View>
    </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    
    
    backgroundColor: '#fff',
  },
  label: {
    fontSize: 16,
    margin: 7,
  },
  input: {
    height: 40,
    borderWidth: 1,
    backgroundColor:'#D0EFCB',
    borderColor: 'black',
    borderRadius: 5,
    paddingHorizontal: 10,
    margin: 7,
  },
  textArea: {
    borderWidth: 1,
    backgroundColor:'#D0EFCB',
    borderColor: 'black',
    borderRadius: 5,
    padding: 10,
    height: 120, // Set height according to your preference
    textAlignVertical: 'top', // Align text at the top
  },
  picker: {
    height: 30,
    borderWidth: 1,
    backgroundColor:'#D0EFCB',
    borderColor: 'black',
    borderRadius: 5,
    marginBottom: 20,
  },button1: {
    backgroundColor: '#024c12',
    color: 'white',
    textAlign: 'center',
    padding: 10,
    borderRadius: 5,
    marginBottom: 10,
    width:120,
  },
  button2: {
    backgroundColor: 'lightgrey',
    color: 'black',
    textAlign: 'center',
    padding: 10,
    borderRadius: 5,
    marginBottom: 10,
    width:120,
  }
});

export default AssignTaskPnpl;
